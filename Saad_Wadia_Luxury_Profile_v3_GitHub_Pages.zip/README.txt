SAAD WADIA — EDITION 03
Upload the CONTENTS of this folder to the root of a public GitHub repository.
Ensure index.html is at the repository root and the images folder sits beside it.
Then go to Settings > Pages > Deploy from a branch > main > /(root) > Save.
Note: income/revenue claims have intentionally not been added without verification.
